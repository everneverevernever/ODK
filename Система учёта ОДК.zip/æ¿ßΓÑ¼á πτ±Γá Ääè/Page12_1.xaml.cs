﻿using Microsoft.Win32;
using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page12_1.xaml
    /// </summary>
    public partial class Page12_1 : Page
    {
        DataTable Table = new DataTable();
        public Page12_1()
        {
            InitializeComponent();
            Table.Columns.Add("name");
            ComponentsGrid.DataContext = Table;
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog
            {
                Title = "Select a picture",
                Filter = "All supported graphics|*.jpg;*.jpeg;*.jfif;*.png|" +
                "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
                "Portable Network Graphic (*.png)|*.png"
            };

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page11_3());
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }
    }
}
