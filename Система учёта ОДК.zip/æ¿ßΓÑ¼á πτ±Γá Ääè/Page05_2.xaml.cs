﻿using Microsoft.Win32;
using System;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Text.RegularExpressions;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page_V.xaml
    /// </summary>
    public partial class Page05_2 : Page
    {
        public Page05_2()
        {
            InitializeComponent();
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

            if (Nam.Text.Length == 0) //         
            {
                return;
            }

            if (Comment.Text.Length == 0) // 
            {
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                string query = "INSERT INTO Dismanting_by_contractor ([remark],[date_of_remark_elimination],[description],[photo]) VALUES (@h_n,@n_d,@t_o,@c)";
                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand(query, con);

                command.Parameters.AddWithValue("@h_n", Zamet.Text);
                command.Parameters.AddWithValue("@n_d", Nam.Text);
                command.Parameters.AddWithValue("@t_o", Comment.Text);
                //  command.Parameters.AddWithValue("@c", ComboBox_contarctor.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные введены");
            }

        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e) {
            Zamet.IsEnabled = true;
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page06());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page05_1());
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.jfif;*.png|" +
              "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == true)
            {
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
            }
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
