﻿using System.Windows;



namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            Navigation.NavigationService.Navigate(new MainPage());
        }
    }
}

