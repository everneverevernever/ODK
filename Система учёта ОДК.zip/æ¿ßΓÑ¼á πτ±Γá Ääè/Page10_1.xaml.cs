﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page10_1.xaml
    /// </summary>
    public partial class Page10_1 : Page
    {
        public Page10_1()
        {
            InitializeComponent();
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page10_2());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page09());
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "Все изображения|*.jpg;*.jpeg;*.jfif;*.png|" +
              "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
              "Portable Network Graphic (*.png)|*.png";

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }
    }
}
