﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void GoPage1_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_1());
        }

        private void GoPage1_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_2());
        }

        private void GoPage2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page02());
        }

        private void GoPage3_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_01());
        }

        private void GoPage3_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_2());
        }

        private void GoPage4_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page04_1());
        }

        private void GoPage4_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page04_2());
        }

        private void GoPage5_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page05_1());
        }

        private void GoPage5_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page05_2());
        }

        private void GoPage6(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page06());
        }

        private void GoPage7(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page07());
        }

        private void GoPage8(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page08());
        }

        private void GoPage9(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page09());
        }

        private void GoPage10_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page10_1());
        }

        private void GoPage10_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page10_2());
        }

        private void GoPage11_1(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page11_1());
        }

        private void GoPage11_2(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page11_2());
        }

        private void GoPage11_3(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page11_3());
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_1());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page11_3());
        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page12_1());
        }
    }
}
