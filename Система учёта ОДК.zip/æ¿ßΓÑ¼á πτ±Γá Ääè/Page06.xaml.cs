﻿using System.Data;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page06.xaml
    /// </summary>
    public partial class Page06 : Page
    {
        DataTable dt = new DataTable("content");

        public Page06()
        {
            InitializeComponent();
            LoadWarehouses();
            LoadContractors();
            LoadAddresses();
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page07());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page05_2());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (WarehouseSelector.Text.Length == 0) // проверка склада  
            {
                MessageBox.Show("Вы не выбрали склад");
                return;
            }

            if (ContractorSelector.Text.Length == 0) // проверяем наличия подрядчика         
            {
                MessageBox.Show("Вы не выбрали подрядчика");
                return;
            }

            if (AddressSelector.Text.Length == 0) // проверяем адреса
            {
                MessageBox.Show("Вы не выбрали адрес");
                return;
            }

            if (ODKSelector.Text.Length == 0) // проверяем ОДК
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();

                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand("INSERT INTO write_off ([warehouse],[contractor],[AddressSelector],[ODK]) VALUES (@w,@c,@ad,@ODKSelector)", con);

                command.Parameters.AddWithValue("@w", WarehouseSelector.Text);
                command.Parameters.AddWithValue("@c", ContractorSelector.Text);
                command.Parameters.AddWithValue("@ad", AddressSelector.Text);
                command.Parameters.AddWithValue("@ODKSelector", ODKSelector.Text);

                command.ExecuteNonQuery();

                MessageBox.Show("Данные введены");
            }
        }

        private void LoadWarehouses() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refWarehouses", con).ExecuteReader())
                    while (reader.Read())
                        WarehouseSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadContractors() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                        ContractorSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadAddresses() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refAddresses", con).ExecuteReader())
                    while (reader.Read())
                        AddressSelector.Items.Add(reader["name"].ToString());
            }
        }
    }

}
