﻿using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page03_2_.xaml
    /// </summary>
    public partial class Page03_2 : Page
    {
        public Page03_2()
        {
            InitializeComponent();
            LoadContractors();
            LoadODK();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (ContractorSelector.Text.Length == 0) // проверка праздника     
            {
                MessageBox.Show("Вы не выбрали подрдячика");
                return;
            }

            if (AdressInput.Text.Length == 0) // проверяем адрес        
            {
                MessageBox.Show("Вы не ввели адрес");
                return;
            }

            if (ODKSelector.Text.Length == 0) // проверяем ОДК 
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            if (ConnInput.Text.Length == 0) // проверяем точка подключения
            {
                MessageBox.Show("Вы не ввели точку подключения");
                return;
            }

            if (SwitchAddrInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не выбрали адрес");
                return;
            }

            if (RegionInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели административный округ г.  Москвы установки ОДК");
                return;
            }

            if (RESInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели ответственного РЭС");
                return;
            }

            if (ContractorNameInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели имя ответственного подрядчика");
                return;
            }

            if (ContractorNumberInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели номер ответственного подрядчика");
                return;
            }

            if (NumODKInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели количество ОДК");
                return;
            }

            if (PlannedODKModeInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели режим работы ОДК по плану");
                return;
            }

            if (ODKModeInput.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не ввели режим работы ОДК по факту");
                return;
            }

            if (DateSelector.Text.Length == 0) // проверка адресса
            {
                MessageBox.Show("Вы не выбрали планируемую дату монтажа");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();

                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand("INSERT INTO installation_details ([contractor],[adress],[ODK],[place_of_intallation],[adress_of_auto_switch],[dgu_installation],[administrative_district],[RES],[contractor's_fio],[contractor's_telephone],[ODK_quantity],[%_completed],[operating_mode_plan],[operating_mode_fact],[installation_daty]) VALUES (@h_n,@n_d,@t_o,@c,@o_d,@q_o,@tr,@y_t,@t_y,@g_i,@d_j,@a_s,@p_i,@z_x,@e_r)", con);

                command.Parameters.AddWithValue("@h_n", ContractorSelector.Text);
                command.Parameters.AddWithValue("@n_d", AdressInput.Text);
                command.Parameters.AddWithValue("@t_o", ODKSelector.Text);
                command.Parameters.AddWithValue("@c", ConnInput.Text);
                command.Parameters.AddWithValue("@o_d", SwitchAddrInput.Text);
                command.Parameters.AddWithValue("@q_o", RegionInput.Text);
                command.Parameters.AddWithValue("@tr", RESInput.Text);
                command.Parameters.AddWithValue("@y_t", ContractorSelector.Text);
                command.Parameters.AddWithValue("@t_y", AdressInput.Text);
                command.Parameters.AddWithValue("@g_i", ODKSelector.Text);
                command.Parameters.AddWithValue("@d_j", ConnInput.Text);
                command.Parameters.AddWithValue("@a_s", SwitchAddrInput.Text);
                command.Parameters.AddWithValue("@p_i", RegionInput.Text);
                command.Parameters.AddWithValue("@z_x", RESInput.Text);
                command.Parameters.AddWithValue("@e_r", RegionInput.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные введены");
            }
        }

        private void LoadContractors() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                        ContractorSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadODK() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refAxp", con).ExecuteReader())
                    while (reader.Read())
                        ODKSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_01());
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page04_1());
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainWindow());
        }
    }

}



