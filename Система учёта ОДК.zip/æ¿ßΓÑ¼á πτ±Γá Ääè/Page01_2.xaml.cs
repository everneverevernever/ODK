﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Text.RegularExpressions;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page01_2.xaml
    /// </summary>
    public partial class Page01_2 : Page
    {
        List<int> ContractIDs = new List<int>();
        List<int> ContractorIDs = new List<int>();
        List<int> ODKIDs = new List<int>();
        List<int> WarehouseIDs = new List<int>();
        Regex Regex = new Regex("[^0-9]+");

        public Page01_2()
        {
            InitializeComponent();
            LoadContracts();
            LoadContractors();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            // Проверяем, введены ли обязательные данные
            if (ContractorSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали подрядчика");
                return;
            }

            if (WarehouseSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали склад");
                return;
            }

            if (ContactSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали контакт");
                return;
            }

            if (ODKSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            if (ODKNumInput.Text.Length == 0)
            {
                MessageBox.Show("Вы не ввели количество полных комплектов ОДК");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                // Создаём команду добавления данных в БД
                OleDbCommand command = new OleDbCommand("INSERT INTO initial_warehouse ([holiday_name],[namber_date_ODK],[type_ODK],[contractor],[ODK_type],[quantity_ODK]) VALUES (@h_n,@n_d,@t_o,@c,@o_d,@q_o)", con);

                // Заполняем команду данными
                command.Parameters.AddWithValue("@h_n", ContractorSelector.Text);
                command.Parameters.AddWithValue("@n_d", WarehouseSelector.Text);
                command.Parameters.AddWithValue("@t_o", ContactSelector.Text);
                command.Parameters.AddWithValue("@c", ODKSelector.Text);
                command.Parameters.AddWithValue("@o_d", ContractSelector.Text);
                command.Parameters.AddWithValue("@q_o", ContractSelector.Text);

                command.ExecuteNonQuery();

                MessageBox.Show("Данные введены");
            }
        }

        private void LoadContracts()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();

                using (var reader = new OleDbCommand("SELECT [id], contract_date, [contract_number] FROM tblBoughtConstructions WHERE NOT [contract_number] = 0", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ContractIDs.Add(reader.GetInt32(0));
                        ContractSelector.Items.Add("Договор №" + reader.GetInt32(2).ToString() + " от " + reader.GetDateTime(1).ToString("dd.MM.yyyy"));
                    }

                using (var reader = new OleDbCommand("SELECT [id] FROM tblBoughtConstructions WHERE [contract_number] = 0", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ContractIDs.Add(reader.GetInt32(0));
                        ContractSelector.Items.Add("Ненумерованный договор #" + reader.GetInt32(0).ToString());
                    }
            }
        }

        // Загружает список подрядчиков из БД в соответствующий ComboBox
        private void LoadContractors()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT [id], [name] FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ContractorSelector.Items.Add(reader["name"].ToString());
                        ContractorIDs.Add(reader.GetInt32(0));
                    }
            }
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page02());
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainPage());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_1());
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e) {
            e.Handled = Regex.IsMatch(e.Text);
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog
            {
                Title = "Select a picture",
                Filter = "All supported graphics|*.jpg;*.jpeg;*.jfif;*.png|" +
                "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
                "Portable Network Graphic (*.png)|*.png"
            };

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }

        private void ODKTypeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ODKSelector.Items.Clear();
            ODKIDs.Clear();
            switch (ODKTypeSelector.SelectedIndex)
            {
                case 0:
                    ODKNumLabel.Content = "Введите количество ОДК*";
                    LoadODK();
                    break;
                case 1:
                    ODKNumLabel.Content = "Введите количество элементов ОДК*";
                    LoadODKElements();
                    break;
                case -1:
                    return;
            }

            ODKSelector.IsEnabled = true;
        }

        // Загружает список ОДК из БД в соответствующий ComboBox
        private void LoadODK()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT id, [name] FROM refAxp", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ODKSelector.Items.Add(reader["name"].ToString());
                        ODKIDs.Add(reader.GetInt32(0));
                    }
            }
        }

        // Загружает список элементов ОДК из БД в соответствующий ComboBox
        private void LoadODKElements()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT id, [name] FROM refAxpElements", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ODKSelector.Items.Add(reader["name"].ToString());
                        ODKIDs.Add(reader.GetInt32(0));
                    }
            }
        }
    }

}