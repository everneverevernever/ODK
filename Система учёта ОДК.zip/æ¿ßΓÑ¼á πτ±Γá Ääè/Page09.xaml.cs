﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page09.xaml
    /// </summary>
    public partial class Page09 : Page
    {
        public Page09()
        {
            InitializeComponent();
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page10_1());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page08());
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }
    }
}
