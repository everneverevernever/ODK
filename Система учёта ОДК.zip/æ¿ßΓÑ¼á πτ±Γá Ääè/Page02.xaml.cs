﻿using System.Data;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page02.xaml
    /// </summary>
    public partial class Page02 : Page
    {
        DataTable DT = new DataTable("content");

        public Page02()
        {
            InitializeComponent();
            LoadWarehouses();
            LoadContractors();
            LoadEvents();
            LoadODK();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (WarehourseSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали склад");
                return;
            }

            if (ContractorSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали поставщика");
                return;
            }

            if (EventSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали праздник");
                return;
            }

            if (ODKSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand("INSERT INTO issu_of_odk ([warehouse],[contractor],[event],[contractor],[ODK_type],[quantity_ODK]) VALUES (@h_n,@n_d,@t_o,@c,@o_d,@q_o)", con);

                command.Parameters.AddWithValue("@h_n", WarehourseSelector.Text);
                command.Parameters.AddWithValue("@n_d", ContractorSelector.Text);
                command.Parameters.AddWithValue("@t_o", EventSelector.Text);
                command.Parameters.AddWithValue("@c", ODKSelector.Text);
                MessageBox.Show("Данные введены");
                command.ExecuteNonQuery();
            }
        }

        private void LoadWarehouses() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refWarehouses", con).ExecuteReader())
                    while (reader.Read())
                        WarehourseSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadContractors() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                        ContractorSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadEvents() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refEvents", con).ExecuteReader())
                    while (reader.Read())
                        EventSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadODK() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refAxp", con).ExecuteReader())
                    while (reader.Read())
                        ODKSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainPage());
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_01());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_2());
        }
    }

}