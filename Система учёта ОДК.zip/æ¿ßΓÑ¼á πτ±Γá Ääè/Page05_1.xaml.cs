﻿using System;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.Win32;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page05.xaml
    /// </summary>
    public partial class Page05_1 : Page
    {
        public Page05_1()
        {
            InitializeComponent();
            InitializeComponent();
            LoadComboLogged();
            LoadComboLogged_2();
            LoadComboLogged_3();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (ContractorSelector.Text.Length == 0) // проверка подрядчика     
            {
                MessageBox.Show("Вы не выбрали подрядчика");
                return;
            }

            if (AddressSelector.Text.Length == 0) // проверяем адрес
            {
                MessageBox.Show("Вы не выбрали адрес");
                return;
            }

            if (ODKSelector.Text.Length == 0) // проверяем ОДК 
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            if (CommentInput.Text.Length == 0) // проверяем комментарий
            {
                MessageBox.Show("Вы не ввели комментарий");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();

                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand("INSERT INTO Purchased_ODK ([holiday_name],[namber_date_ODK],[type_ODK],[contractor],[ODK_type],[quantity_ODK]) VALUES (@h_n,@n_d,@t_o,@c,@o_d,@q_o)", con);

                command.Parameters.AddWithValue("@h_n", ContractorSelector.Text);
                command.Parameters.AddWithValue("@n_d", AddressSelector.Text);
                command.Parameters.AddWithValue("@t_o", ODKSelector.Text);
                command.Parameters.AddWithValue("@c", CommentInput.Text);

                command.ExecuteNonQuery();

                MessageBox.Show("Данные введены");
            }
        }

        private void LoadComboLogged() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM NameH", con).ExecuteReader())
                    while (reader.Read())
                        ContractorSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadComboLogged_2() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                        AddressSelector.Items.Add(reader["name"].ToString());
            }
        }

        private void LoadComboLogged_3() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader_2 = new OleDbCommand("SELECT * FROM refAxp", con).ExecuteReader())
                    while (reader_2.Read())
                        ODKSelector.Items.Add(reader_2["name"].ToString());
            }
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page05_2());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page04_2());
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainPage());
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog
            {
                Title = "Select a picture",
                Filter = "Все изображения|*.jpg;*.jpeg;*.jfif;*.png|" +
                "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
                "Portable Network Graphic (*.png)|*.png"
            };

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }
    }
}
