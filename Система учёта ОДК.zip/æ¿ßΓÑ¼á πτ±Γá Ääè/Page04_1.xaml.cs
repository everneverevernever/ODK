﻿using Microsoft.Win32;
using System;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Text.RegularExpressions;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page04.xaml
    /// </summary>
    public partial class Page04_1 : Page
    {
        Regex Regex = new Regex("[^0-9]+");

        public Page04_1()
        {
            InitializeComponent();
            LoadComboLogged();
            LoadComboLogged_2();
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page04_2());
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_2());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (Montaj.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали информацию о монтаже");
                return;
            }
            if (Montaj1.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали информацию о монтаже");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                // текст запроса
                string query = "INSERT INTO installation_results ([install_1],[install_2]) VALUES (@i_1,@1_2)";
                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand(query, con);

                command.Parameters.AddWithValue("@i_1", Montaj.Text);
                command.Parameters.AddWithValue("@i_2", Montaj1.Text);

                MessageBox.Show("Данные введены");
                command.ExecuteNonQuery();
            }
        }

        private void LoadComboLogged() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM install_information_1", con).ExecuteReader())
                    while (reader.Read())
                        Montaj.Items.Add(reader["installation"].ToString());
            }
        }

        private void LoadComboLogged_2() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM install_information_2", con).ExecuteReader())
                    while (reader.Read())
                        Montaj1.Items.Add(reader["reception_install"].ToString());
            }
        }
        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.jfif;*.png|" +
              "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainWindow());
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e) {
            e.Handled = Regex.IsMatch(e.Text);
        }

    }
}

