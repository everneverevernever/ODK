﻿namespace ODKAccounting
{
    class CN
    {
        static public string con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\ODKDB.mdb";
    }
}
