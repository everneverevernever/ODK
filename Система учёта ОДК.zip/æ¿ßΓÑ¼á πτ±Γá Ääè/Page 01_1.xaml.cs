﻿using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Text.RegularExpressions;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page01_1.xaml
    /// </summary>
    public partial class Page01_1 : Page
    {
        List<int> EventIds = new List<int>();
        List<int> ContractorIds = new List<int>();
        List<int> ODKIds = new List<int>();

        public Page01_1()
        {
            InitializeComponent();
            LoadEvents();
            LoadContractors();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            // Проверяем, введены ли обязательные данные
            if (ContractorSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали подрядчика");
                return;
            }

            if (EventSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали мероприятие");
                return;
            }

            if (ODKTypeSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали тип договора о поставке ОДК");
                return;
            }

            if (ODKSelector.SelectedIndex == -1)
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            }

            if (ODKNumInput.Text.Length == 0)
            {
                MessageBox.Show("Вы не введли количество ОДК");
                return;
            }

            if (ODKTypeSelector.SelectedIndex == 0)
                using (var con = new OleDbConnection(CN.con))
                {
                    con.Open();

                    // Создаём команду добавления данных в БД
                    OleDbCommand command;
                    if (ODKIdInput.Text.Length == 0)
                    {
                        command = new OleDbCommand("INSERT INTO tblBoughtConstructions ([axp_id], [contractor_id], [count_odk], [event_id]) VALUES (@axp, @con, @cnt, @evi)", con);
                    }
                    else
                    {
                        command = new OleDbCommand("INSERT INTO tblBoughtConstructions ([axp_id], [contractor_id], [count_odk], [event_id], [contract_date], [contract_number]) VALUES (@axp, @con, @cnt, @evi, @cda, @cnu)", con);
                        command.Parameters.AddWithValue("@cda", ODKDatePicker.SelectedDate);
                        command.Parameters.AddWithValue("@cnu", ODKIdInput.Text);
                    }
                    
                    // Заполняем команду данными
                    command.Parameters.AddWithValue("@axp", ODKIds[ODKSelector.SelectedIndex]);
                    command.Parameters.AddWithValue("@con", ContractorIds[ContractorSelector.SelectedIndex]);
                    command.Parameters.AddWithValue("@cnt", int.Parse(ODKNumInput.Text));
                    command.Parameters.AddWithValue("@evi", EventIds[EventSelector.SelectedIndex]);

                    // Исполняем команду
                    MessageBox.Show(command.CommandText);
                }
            else
                using (var con = new OleDbConnection(CN.con))
                {
                    con.Open();

                    // Создаём команду добавления данных в БД
                    OleDbCommand command;
                    if (ODKIdInput.Text.Length == 0)
                        command = new OleDbCommand("INSERT INTO tblBoughtConstructionElements ([axp_element_id], [contractor_id], [count_element], [event_id]) VALUES (@axp, @con, @cnt, @evi)", con);
                    else
                    {
                        command = new OleDbCommand("INSERT INTO tblBoughtConstructionElements ([axp_element_id], [contractor_id], [count_element], [event_id], [contract_date], [contract_number]) VALUES (@axp, @con, @cnt, @evi, @cda, @cnu)", con);
                        command.Parameters.AddWithValue("@cda", ODKDatePicker.SelectedDate);
                        command.Parameters.AddWithValue("@cnu", ODKIdInput.Text);
                    }


                    // Заполняем команду данными
                    command.Parameters.AddWithValue("@axp", ODKIds[ODKSelector.SelectedIndex]);
                    command.Parameters.AddWithValue("@con", ContractorIds[ContractorSelector.SelectedIndex]);
                    command.Parameters.AddWithValue("@cnt", int.Parse(ODKNumInput.Text));
                    command.Parameters.AddWithValue("@evi", EventIds[EventSelector.SelectedIndex]);

                    // Исполняем команду
                    MessageBox.Show(command.CommandText);
                }

            MessageBox.Show("Данные введены");
        }

        // Загрудает список пряздников из БД в соответствующий ComboBox
        private void LoadEvents()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT id, name FROM refEvents", con).ExecuteReader())
                    while (reader.Read())
                    {
                        EventSelector.Items.Add(reader["name"].ToString());
                        EventIds.Add(reader.GetInt32(0));
                    }
            }
        }

        // Загружает список подрядчиков из БД в соответствующий ComboBox
        private void LoadContractors()
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT [id], [name] FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ContractorSelector.Items.Add(reader["name"].ToString());
                        ContractorIds.Add(reader.GetInt32(0));
                    }
            }
        }

        // Перемещает на следующую страницу
        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page01_2());
        }
        

        // Перемещает на главную страницу
        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainPage());
        }

        // Проверка, являются ли введённые данные числом
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void ODKTypeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (ODKTypeSelector.SelectedIndex)
            {
                case -1:
                    return;
                case 0:
                    ODKNumLabel.Content = "Введите количество ОДК*";
                    LoadODK();
                    break;
                case 1:
                    ODKNumLabel.Content = "Введите количество элементов ОДК*";
                    LoadODKElements();
                    break;
            }

            ODKSelector.IsEnabled = true;
        }

        // Загружает список ОДК из БД в соответствующий ComboBox
        private void LoadODK()
        {
            ODKSelector.Items.Clear();
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT id, [name] FROM refAxp", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ODKSelector.Items.Add(reader["name"].ToString());
                        ODKIds.Add(reader.GetInt32(0));
                    }
            }
        }

        // Загружает список элементов ОДК из БД в соответствующий ComboBox
        private void LoadODKElements()
        {
            ODKSelector.Items.Clear();
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT id, [name] FROM refAxpElements", con).ExecuteReader())
                    while (reader.Read())
                    {
                        ODKSelector.Items.Add(reader["name"].ToString());
                        ODKIds.Add(reader.GetInt32(0));
                    }
            }
        }
    }
}
