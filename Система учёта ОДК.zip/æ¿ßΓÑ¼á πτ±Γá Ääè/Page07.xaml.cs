﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page07.xaml
    /// </summary>
    public partial class Page07 : Page
    {
        public Page07()
        {
            InitializeComponent();
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page08());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page06());
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "Все изображения|*.jpg;*.jpeg;*.jfif;*.png|" +
              "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
              "Portable Network Graphic (*.png)|*.png";

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }
    }
}
