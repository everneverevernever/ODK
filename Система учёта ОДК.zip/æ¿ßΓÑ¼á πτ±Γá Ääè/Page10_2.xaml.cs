﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для page10_2.xaml
    /// </summary>
    public partial class Page10_2 : Page
    {
        public Page10_2()
        {
            InitializeComponent();
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page11_1());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page10_1());
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "Все изображения|*.jpg;*.jpeg;*.jfif;*.png|" +
              "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
              "Portable Network Graphic (*.png)|*.png";

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }
    }
}
