﻿using System;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.Win32;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page03.xaml
    /// </summary>
    public partial class Page03_01 : Page
    {
        public Page03_01()
        {
            InitializeComponent();
            LoadContractors();
            LoadODK();
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {
            if (ContractorSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали подрядчика");
                return;
            } // проверка праздника     

            if (AdressSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали адресс");
                return;
            } // проверяем наличия даты        

            if (ODKSelector.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали ОДК");
                return;
            } // проверяем ОДК 

            if (ODKNumInput.Text.Length == 0)
            {
                MessageBox.Show("Вы не выбрали количество ОДК");
                return;
            } // проверяем введён подрядчик

            if (CommentInput.Text.Length == 0)
            {
                MessageBox.Show("Вы не ввели комментарий к монтажу");
                return;
            } // проверяем введён подрядчик

            if (LocationCommentInput.Text.Length == 0)
            {
                MessageBox.Show("Вы не ввели комментарий к месту установки");
                return;
            }

            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                // создаем объект OleDbCommand для выполнения запроса к БД MS Access
                OleDbCommand command = new OleDbCommand("INSERT INTO installation ([contractor],[address],[ODK],[installing_sets_of_ODK],[comment],[comment2]) VALUES (@h_n,@n_d,@t_o,@c,@o_d,@q_o)", con);

                command.Parameters.AddWithValue("@h_n", ContractorSelector.Text);
                command.Parameters.AddWithValue("@n_d", AdressSelector.Text);
                command.Parameters.AddWithValue("@t_o", ODKSelector.Text);
                command.Parameters.AddWithValue("@c", ODKNumInput.Text);
                command.Parameters.AddWithValue("@o_d", CommentInput.Text);
                command.Parameters.AddWithValue("@q_o", LocationCommentInput.Text);

                MessageBox.Show("Данные введены");
                command.ExecuteNonQuery();
            }
        }

        private void ImageSelect(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog
            {
                Title = "Select a picture",
                Filter = "All supported graphics|*.jpg;*.jpeg;*.jfif;*.png|" +
                "JPEG (*.jpg, *.jpeg, *.jfif)|*.jpg;*.jpeg;*.jfif|" +
                "Portable Network Graphic (*.png)|*.png"
            };

            if (op.ShowDialog() == true)
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
        }
        private void LoadContractors() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader = new OleDbCommand("SELECT * FROM refContractors", con).ExecuteReader())
                    while (reader.Read())
                        ContractorSelector.Items.Add(reader["name"].ToString());
            }
        }
        private void LoadODK() // Эти блоки подгружают информаци из базы данных для выборки в ComboBox
        {
            using (var con = new OleDbConnection(CN.con))
            {
                con.Open();
                using (OleDbDataReader reader2 = new OleDbCommand("SELECT * FROM refAxp", con).ExecuteReader())
                    while (reader2.Read())
                        ContractorSelector.Items.Add(reader2["name"].ToString());
            }
        }

        private void GoBack(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page02());
        }

        private void GoForward(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new Page03_2());
        }

        private void GoMain(object sender, RoutedEventArgs e) {
            NavigationService.Navigate(new MainWindow());
        }
    }
}

