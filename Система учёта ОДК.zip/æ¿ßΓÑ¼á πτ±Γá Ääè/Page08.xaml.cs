﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace ODKAccounting
{
    /// <summary>
    /// Логика взаимодействия для Page08.xaml
    /// </summary>
    public partial class Page08 : Page
    {
        public Page08()
        {
            InitializeComponent();
        }

        private void GoForward(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page09());
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page07());
        }

        private void GoMain(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void SaveData(object sender, RoutedEventArgs e)
        {

        }
    }
}
