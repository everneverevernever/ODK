from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QMessageBox, QApplication, QMainWindow, QVBoxLayout, QCheckBox, QWidget
from itertools import chain
from check_skrin import *
from connection import *

class Main(QtWidgets.QWidget, Ui_Form):
    def __init__(self, parent=None):
        super(Main, self).__init__(parent)
        self.setupUi(self)
        self.checks = []
        self.idMeter = None # id счётчка
        self.listRateTariff = None # список значений стоимости тарифа
        self.idTariff = None # id тарифа
        self.diffReading = None # разница показний
        self.discounts = [] # скидки за льготы

        device = QwSql().getDevice()
        facilities = QwSql().getFacilities
        tariffs = QwSql().getTariffs()

        # добавляем названия в comboBox
        for i in device:
            self.comboBox.addItem(i[1])

        # блокировка первого элемента comboBox
        self.comboBox.model().item(0).setEnabled(False)
        self.comboBox.currentTextChanged.connect(lambda: self.addFacilities(device, facilities))

        # подключение кнопок
        self.btn_calc.clicked.connect(self.onClickCheck)
        self.btn_write.clicked.connect(self.setInDb)

        # добавление radioButton в GroupBox
        height = 40
        for tarif in tariffs:
            rad = QtWidgets.QRadioButton(parent=self.grBox)
            rad.setGeometry(20, height, 191, 21)
            rad.setObjectName(f"{tarif[1]}")
            rad.setText(f"{tarif[1]}")
            rad.setAccessibleName(f"{tarif[0]}")
            rad.setAccessibleDescription(f"{tarif[2]}")
            rad.toggled.connect(self.onTogled) # соединение с sender чтобы определить какой radioButton нажат
            height += 40
            
    def onTogled(self, checked):
        try:
            radio = self.sender()
            if checked:
                self.listRateTariff = float(radio.accessibleDescription())
                self.idTariff = radio.accessibleName()
        except Exception as e:
            print(e)

    def onClickCheck(self):
        try:
            le = self.lineEdit.text() # показания счётчика
            self.read = le

            self.discounts.clear()

            checked = (' '.join([checkbox.text() for checkbox in self.checks if checkbox.isChecked()])).split(' ') # список прожатых чекбоксов
            for checkbox in checked:
                self.discounts.append(float(QwSql().getRate(checkbox))) # прожатые чекбоксы добавляются в список

            self.diffReading = QwSql().getDiffReading(self.idMeter, self.read) # разница между прошлым и нынещним показателем счётчика


            if not self.discounts:  # если список  пуст то делается расчёт без скидок
                self.amount = float(self.diffReading) * float(self.listRateTariff)

            else:
                self.amount = float(self.diffReading) * float(self.listRateTariff) - (float(self.diffReading) * float(self.listRateTariff) * sum(self.discounts))


            self.ll.setText(str(self.amount))
            self.ll.adjustSize()
        except Exception as e:
            print(e)


    def addFacilities(self, device, facilities):
        try:
            # очистка layout
            while self.VL.count():
                item = self.VL.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()

            comb = self.comboBox.currentText() # достаём значение comboBox
            new_data_qw = list(chain.from_iterable(device)) # достаём все вложенные списки в один общий
            index = new_data_qw.index(comb) - 1
            element = new_data_qw[index]
            self.idMeter = element
            facilities = facilities(element) # получаем льготы
            for name in facilities[0]:
                if name != None: # если льгота не пустая добавляем в layOut чекбоксы
                    self.checkbox = QCheckBox(name)
                    self.checks.append(self.checkbox)
                    self.VL.addWidget(self.checkbox)
        except Exception as e:
            print(e)


    def setInDb(self): # запись в бд
        try:
            QwSql().setBills(self.read, self.amount, self.idTariff, self.idMeter)
        except Exception as e:
            print(e)

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    wind = Main()
    wind.show()
    sys.exit(app.exec())