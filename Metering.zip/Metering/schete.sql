-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 18 2024 г., 02:53
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `schete`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`root`@`%` PROCEDURE `xp1` (IN `reading_id` INT)   BEGIN
    DECLARE underage_count INT;
    DECLARE elder_count INT;
    DECLARE underage_privilege VARCHAR(255);
    DECLARE elder_privilege VARCHAR(255);

    -- Считаем количество лиц младше 18 лет
    SELECT COUNT(*) INTO underage_count
    FROM RegisteredIndividuals
    WHERE TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 18
    AND metering_device_id = (SELECT metering_device_id FROM MeterReadings WHERE id = reading_id);

    -- Считаем количество лиц старше 55 лет
    SELECT COUNT(*) INTO elder_count
    FROM RegisteredIndividuals
    WHERE TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) > 55
    AND metering_device_id = (SELECT metering_device_id FROM MeterReadings WHERE id = reading_id);

    -- Определяем типы льгот
    IF underage_count >= 3 THEN
        SELECT name INTO underage_privilege
        FROM PrivilegeTypes
        WHERE id = 1; -- ID для типа льготы "Многодетная семья"
    END IF;

    IF elder_count > 0 THEN
        SELECT name INTO elder_privilege
        FROM PrivilegeTypes
        WHERE id = 2; -- ID для типа льготы "Пенсионер"
    END IF;

    -- Выводим результат
    SELECT underage_privilege AS underage_privilege_type, elder_privilege AS elder_privilege_type;
END$$

CREATE DEFINER=`root`@`%` PROCEDURE `xp3` (IN `device_id` INT, IN `current_reading` DECIMAL(10,2))   BEGIN
    DECLARE last_reading DECIMAL(10,2);
    DECLARE difference DECIMAL(10,2);
    
    -- Найдем последнее показание для данного прибора учета
    SELECT reading INTO last_reading
    FROM MeterReadings
    WHERE metering_device_id = device_id
    ORDER BY date_time DESC
    LIMIT 1;
    
    -- Если есть последнее показание, вычислим разницу
    IF last_reading IS NOT NULL THEN
        SET difference = current_reading - last_reading;
        SELECT difference AS meter_reading_difference;
    ELSE
        SELECT 'No previous reading found for the device' AS message;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `MeteringDevice`
--

CREATE TABLE `MeteringDevice` (
  `id` int NOT NULL,
  `number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `MeteringDevice`
--

INSERT INTO `MeteringDevice` (`id`, `number`, `address`) VALUES
(1, '001', 'ул. Ленина, д. 10'),
(2, '002', 'ул. Пушкина, д. 25'),
(3, '003', 'пр. Мира, д. 5');

-- --------------------------------------------------------

--
-- Структура таблицы `MeterReadings`
--

CREATE TABLE `MeterReadings` (
  `id` int NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `reading` decimal(10,2) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `tariff_id` int DEFAULT NULL,
  `metering_device_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `MeterReadings`
--

INSERT INTO `MeterReadings` (`id`, `date_time`, `reading`, `amount`, `tariff_id`, `metering_device_id`) VALUES
(1, '2024-04-03 16:50:11', '4.00', '5000.00', 2, 1),
(2, '2024-04-04 16:53:59', '3.00', '5000.00', 2, 2),
(3, '2024-04-03 16:50:11', '4.00', '5000.00', 2, 2),
(4, '2024-04-06 01:13:44', '20.00', '5000.00', 2, 1),
(5, '2024-02-01 04:20:59', '45.00', '45.25', 1, 1),
(6, '2024-04-18 02:41:45', '45.00', '45.25', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `PrivilegeTypes`
--

CREATE TABLE `PrivilegeTypes` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `PrivilegeTypes`
--

INSERT INTO `PrivilegeTypes` (`id`, `name`, `rate`) VALUES
(1, 'многодетные', '0.70'),
(2, 'пенсионер', '0.60');

-- --------------------------------------------------------

--
-- Структура таблицы `RecordedPrivileges`
--

CREATE TABLE `RecordedPrivileges` (
  `id` int NOT NULL,
  `privilege_type_id` int DEFAULT NULL,
  `reading_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `RecordedPrivileges`
--

INSERT INTO `RecordedPrivileges` (`id`, `privilege_type_id`, `reading_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `RegisteredIndividuals`
--

CREATE TABLE `RegisteredIndividuals` (
  `id` int NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `metering_device_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `RegisteredIndividuals`
--

INSERT INTO `RegisteredIndividuals` (`id`, `full_name`, `date_of_birth`, `metering_device_id`) VALUES
(1, 'Иванов Иван Иванович', '1960-05-15', 1),
(2, 'Петров Петр Петрович', '2012-10-20', 1),
(3, 'Сидорова Анна Сергеевна', '2015-03-08', 1),
(4, 'Андреев Андрей Андреич', '2023-03-01', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Tariffs`
--

CREATE TABLE `Tariffs` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Tariffs`
--

INSERT INTO `Tariffs` (`id`, `name`, `rate`) VALUES
(1, 'ночной', '4.31'),
(2, 'дневной', '6.72');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `MeteringDevice`
--
ALTER TABLE `MeteringDevice`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `MeterReadings`
--
ALTER TABLE `MeterReadings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tariff_id` (`tariff_id`),
  ADD KEY `metering_device_id` (`metering_device_id`);

--
-- Индексы таблицы `PrivilegeTypes`
--
ALTER TABLE `PrivilegeTypes`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `RecordedPrivileges`
--
ALTER TABLE `RecordedPrivileges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `privilege_type_id` (`privilege_type_id`),
  ADD KEY `reading_id` (`reading_id`);

--
-- Индексы таблицы `RegisteredIndividuals`
--
ALTER TABLE `RegisteredIndividuals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `metering_device_id` (`metering_device_id`);

--
-- Индексы таблицы `Tariffs`
--
ALTER TABLE `Tariffs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `MeteringDevice`
--
ALTER TABLE `MeteringDevice`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `MeterReadings`
--
ALTER TABLE `MeterReadings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `PrivilegeTypes`
--
ALTER TABLE `PrivilegeTypes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `RecordedPrivileges`
--
ALTER TABLE `RecordedPrivileges`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `RegisteredIndividuals`
--
ALTER TABLE `RegisteredIndividuals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `Tariffs`
--
ALTER TABLE `Tariffs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `MeterReadings`
--
ALTER TABLE `MeterReadings`
  ADD CONSTRAINT `meterreadings_ibfk_1` FOREIGN KEY (`tariff_id`) REFERENCES `Tariffs` (`id`),
  ADD CONSTRAINT `meterreadings_ibfk_2` FOREIGN KEY (`metering_device_id`) REFERENCES `MeteringDevice` (`id`);

--
-- Ограничения внешнего ключа таблицы `RecordedPrivileges`
--
ALTER TABLE `RecordedPrivileges`
  ADD CONSTRAINT `recordedprivileges_ibfk_1` FOREIGN KEY (`privilege_type_id`) REFERENCES `PrivilegeTypes` (`id`),
  ADD CONSTRAINT `recordedprivileges_ibfk_2` FOREIGN KEY (`reading_id`) REFERENCES `MeterReadings` (`id`);

--
-- Ограничения внешнего ключа таблицы `RegisteredIndividuals`
--
ALTER TABLE `RegisteredIndividuals`
  ADD CONSTRAINT `registeredindividuals_ibfk_1` FOREIGN KEY (`metering_device_id`) REFERENCES `MeteringDevice` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
