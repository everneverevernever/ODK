import MySQLdb as mdb
import ast
db = mdb.connect(host='localhost', user='root', password='', database = 'schete')

class QwSql():
    def getDevice(self):
        cur = db.cursor()
        rows = cur.execute(f"SELECT * FROM MeteringDevice ")
        data_qw = cur.fetchall()
        cur.close()
        return data_qw

    def getFacilities(self, id):
        cur = db.cursor()
        rows = cur.execute(f"call xp1('{id}')")
        data_qw = cur.fetchall()
        cur.close()
        return data_qw

    def getTariffs(self):
        cur = db.cursor()
        rows = cur.execute(f"select * from Tariffs ")
        data_qw = cur.fetchall()
        cur.close()
        return data_qw

    def getRate(self, name):
        cur = db.cursor()
        rows = cur.execute(f'SELECT rate FROM `PrivilegeTypes` WHERE name = "{name}";')
        data_qw = cur.fetchone()[0]
        cur.close()
        return data_qw

    def getDiffReading(self, id, read):
        cur = db.cursor()
        rows = cur.execute(f"call xp3('{id}', '{read}')")
        data_qw = cur.fetchone()[0]
        cur.close()
        return data_qw

    def setBills(self,reading, amount, idTariff, idMeter):
        cur = db.cursor()
        rows = cur.execute(f'INSERT INTO MeterReadings (date_time, reading, amount, tariff_id, metering_device_id) VALUES (NOW(), "{reading}", "{amount}", "{idTariff}", "{idMeter}") ')
        db.commit()
        cur.close()
        print('Ответ добавлен')
